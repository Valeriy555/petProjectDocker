import {UsersPage} from "./components";

const App = () => {

  return (
      <div>
        <UsersPage/>
      </div>
  );
};

export default App;
