module.exports = {
    userNormalizator: require('./user.normalizator'),
};