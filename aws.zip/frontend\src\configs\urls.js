// const baseURL  = 'http://localhost:5003/'
const baseURL  = '/api'

const urls = {
    users: '/users'
}

export {
    baseURL,
    urls
}